"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { HelpCircle, Maximize2, Minimize2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Mock function to generate candlestick data
const generateCandlestickData = (count: number, volatility: number) => {
  const data = []
  let price = 100

  for (let i = 0; i < count; i++) {
    const change = (Math.random() - 0.5) * volatility
    const open = price
    price = open + change
    const high = Math.max(open, price) + Math.random() * volatility * 0.5
    const low = Math.min(open, price) - Math.random() * volatility * 0.5
    const close = price

    data.push({
      date: new Date(2023, 0, i + 1).toISOString().split("T")[0],
      open,
      high,
      low,
      close,
    })
  }

  return data
}

// Mock patterns for identification practice
const patterns = [
  {
    name: "Hammer",
    description:
      "A bullish reversal pattern that forms during a downtrend. It has a small body, little or no upper shadow, and a long lower shadow.",
    characteristics: [
      "Forms during a downtrend",
      "Small body at the upper end of the trading range",
      "Little or no upper shadow",
      "Long lower shadow (at least twice the size of the body)",
    ],
  },
  {
    name: "Shooting Star",
    description:
      "A bearish reversal pattern that forms during an uptrend. It has a small body, little or no lower shadow, and a long upper shadow.",
    characteristics: [
      "Forms during an uptrend",
      "Small body at the lower end of the trading range",
      "Little or no lower shadow",
      "Long upper shadow (at least twice the size of the body)",
    ],
  },
  {
    name: "Engulfing Pattern",
    description:
      "A two-candle reversal pattern where the second candle completely engulfs the body of the first candle.",
    characteristics: [
      "Two-candle pattern",
      "Second candle completely engulfs the body of the first candle",
      "Bullish engulfing forms during a downtrend",
      "Bearish engulfing forms during an uptrend",
    ],
  },
  {
    name: "Doji",
    description: "Indicates indecision in the market. The opening and closing prices are virtually equal.",
    characteristics: [
      "Opening and closing prices are virtually equal",
      "Can have long upper and lower shadows",
      "Indicates indecision in the market",
      "Can signal potential reversal when appearing after a strong trend",
    ],
  },
]

export default function PracticePage() {
  const [chartData, setChartData] = useState<any[]>([])
  const [volatility, setVolatility] = useState(5)
  const [candleCount, setCandleCount] = useState(30)
  const [showGrid, setShowGrid] = useState(true)
  const [selectedPattern, setSelectedPattern] = useState<string | null>(null)
  const [feedback, setFeedback] = useState<{ correct: boolean; message: string } | null>(null)
  const [currentPatternToFind, setCurrentPatternToFind] = useState<string | null>(null)
  const chartRef = useRef<HTMLCanvasElement>(null)
  const [chartScale, setChartScale] = useState(1)

  useEffect(() => {
    generateNewChart()
    selectRandomPatternToFind()
  }, [])

  const generateNewChart = () => {
    const newData = generateCandlestickData(candleCount, volatility)
    setChartData(newData)
    setFeedback(null)
    drawChart(newData)
  }

  const selectRandomPatternToFind = () => {
    const randomIndex = Math.floor(Math.random() * patterns.length)
    setCurrentPatternToFind(patterns[randomIndex].name)
    setSelectedPattern(null)
  }

  const drawChart = (data: any[]) => {
    if (!chartRef.current) return

    const canvas = chartRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set background
    ctx.fillStyle = "#1a1a1a"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Draw grid if enabled
    if (showGrid) {
      ctx.strokeStyle = "#333"
      ctx.lineWidth = 0.5

      // Horizontal grid lines
      for (let i = 0; i <= 10; i++) {
        const y = i * (canvas.height / 10)
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()
      }

      // Vertical grid lines
      for (let i = 0; i <= data.length; i += 5) {
        const x = i * (canvas.width / data.length)
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }
    }

    // Find min and max prices for scaling
    const prices = data.flatMap((d) => [d.high, d.low])
    const minPrice = Math.min(...prices)
    const maxPrice = Math.max(...prices)
    const priceRange = maxPrice - minPrice

    // Draw candlesticks
    const candleWidth = (canvas.width / data.length) * 0.8
    const spacing = (canvas.width / data.length) * 0.2

    data.forEach((candle, i) => {
      const x = i * (candleWidth + spacing) + spacing / 2

      // Scale prices to canvas height
      const scaledOpen = canvas.height - ((candle.open - minPrice) / priceRange) * canvas.height
      const scaledClose = canvas.height - ((candle.close - minPrice) / priceRange) * canvas.height
      const scaledHigh = canvas.height - ((candle.high - minPrice) / priceRange) * canvas.height
      const scaledLow = canvas.height - ((candle.low - minPrice) / priceRange) * canvas.height

      // Draw wick
      ctx.strokeStyle = candle.open > candle.close ? "#ef4444" : "#22c55e"
      ctx.beginPath()
      ctx.moveTo(x + candleWidth / 2, scaledHigh)
      ctx.lineTo(x + candleWidth / 2, scaledLow)
      ctx.stroke()

      // Draw body
      ctx.fillStyle = candle.open > candle.close ? "#ef4444" : "#22c55e"
      const bodyTop = Math.min(scaledOpen, scaledClose)
      const bodyHeight = Math.abs(scaledClose - scaledOpen)
      ctx.fillRect(x, bodyTop, candleWidth, bodyHeight)
    })
  }

  const handlePatternSelect = (pattern: string) => {
    setSelectedPattern(pattern)

    // Check if the selected pattern matches the one to find
    if (pattern === currentPatternToFind) {
      setFeedback({
        correct: true,
        message: `Correct! You've identified the ${pattern} pattern.`,
      })
    } else {
      setFeedback({
        correct: false,
        message: `Incorrect. This is not a ${pattern} pattern. Look for a ${currentPatternToFind} pattern.`,
      })
    }
  }

  const handleZoomIn = () => {
    setChartScale((prev) => Math.min(prev + 0.2, 2))
  }

  const handleZoomOut = () => {
    setChartScale((prev) => Math.max(prev - 0.2, 0.5))
  }

  useEffect(() => {
    drawChart(chartData)
  }, [showGrid, chartScale])

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Practice Mode</h1>

      <Tabs defaultValue="pattern-recognition" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="pattern-recognition">Pattern Recognition</TabsTrigger>
          <TabsTrigger value="risk-reward">Risk-to-Reward</TabsTrigger>
          <TabsTrigger value="time-challenge">Time Challenge</TabsTrigger>
        </TabsList>

        <TabsContent value="pattern-recognition">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="h-full">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Candlestick Chart</CardTitle>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={handleZoomOut}>
                        <Minimize2 className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" onClick={handleZoomIn}>
                        <Maximize2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardDescription>Find the {currentPatternToFind} pattern in this chart</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative" style={{ transform: `scale(${chartScale})`, transformOrigin: "center" }}>
                    <canvas
                      ref={chartRef}
                      width={800}
                      height={400}
                      className="w-full h-auto border border-border rounded-lg"
                    />
                  </div>

                  {feedback && (
                    <div
                      className={`mt-4 p-4 rounded-lg ${
                        feedback.correct ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                      }`}
                    >
                      {feedback.message}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex flex-wrap gap-4">
                  <Button onClick={generateNewChart}>Generate New Chart</Button>
                  <Button variant="outline" onClick={selectRandomPatternToFind}>
                    New Pattern to Find
                  </Button>
                  <div className="flex items-center space-x-2 ml-auto">
                    <Switch id="show-grid" checked={showGrid} onCheckedChange={setShowGrid} />
                    <Label htmlFor="show-grid">Show Grid</Label>
                  </div>
                </CardFooter>
              </Card>
            </div>

            <div>
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Pattern Selection</CardTitle>
                  <CardDescription>Select the pattern you've identified</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {patterns.map((pattern) => (
                    <Button
                      key={pattern.name}
                      variant={selectedPattern === pattern.name ? "default" : "outline"}
                      className="w-full justify-start"
                      onClick={() => handlePatternSelect(pattern.name)}
                    >
                      {pattern.name}
                    </Button>
                  ))}

                  <div className="pt-4">
                    <h3 className="font-semibold mb-2">Chart Settings</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="volatility">Volatility: {volatility}</Label>
                        <Slider
                          id="volatility"
                          min={1}
                          max={10}
                          step={1}
                          value={[volatility]}
                          onValueChange={(value) => setVolatility(value[0])}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="candle-count">Candle Count: {candleCount}</Label>
                        <Slider
                          id="candle-count"
                          min={10}
                          max={50}
                          step={5}
                          value={[candleCount]}
                          onValueChange={(value) => setCandleCount(value[0])}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="w-full">
                        <HelpCircle className="mr-2 h-4 w-4" />
                        Pattern Guide
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Candlestick Pattern Guide</DialogTitle>
                        <DialogDescription>Learn to identify common candlestick patterns</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                        {patterns.map((pattern) => (
                          <div key={pattern.name} className="p-4 border rounded-lg">
                            <h3 className="font-semibold text-lg mb-2">{pattern.name}</h3>
                            <p className="text-muted-foreground mb-4">{pattern.description}</p>
                            <h4 className="font-medium mb-2">Key Characteristics:</h4>
                            <ul className="list-disc pl-5 space-y-1">
                              {pattern.characteristics.map((char, i) => (
                                <li key={i} className="text-sm">
                                  {char}
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="risk-reward">
          <Card>
            <CardHeader>
              <CardTitle>Risk-to-Reward Practice</CardTitle>
              <CardDescription>
                Learn to set optimal risk-to-reward ratios for different trading scenarios
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground mb-4">Risk-to-Reward practice module is coming soon!</p>
              <Button disabled>Coming Soon</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="time-challenge">
          <Card>
            <CardHeader>
              <CardTitle>Time Challenge</CardTitle>
              <CardDescription>Test your pattern recognition skills under time pressure</CardDescription>
            </CardHeader>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground mb-4">Time Challenge module is coming soon!</p>
              <Button disabled>Coming Soon</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

