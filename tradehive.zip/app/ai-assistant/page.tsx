"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Brain, Send } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

export default function AIAssistantPage() {
  const { user } = useAuth()
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<any[]>([
    {
      id: 1,
      role: "assistant",
      content:
        "Hello! I'm your AI trading assistant. I can help you with trading concepts, pattern recognition, risk management, and more. What would you like to learn about today?",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!message.trim() || isLoading) return

    const userMessage = {
      id: Date.now(),
      role: "user",
      content: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages((prev) => [...prev, userMessage])
    setMessage("")
    setIsLoading(true)

    try {
      // In a real app, this would use the AI SDK to get a response
      // For demo purposes, we'll simulate a response

      // This is a mock implementation of how you would use the AI SDK
      // In a real app with proper environment variables set up
      /*
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: message,
        system: "You are a helpful AI assistant for traders. Provide concise, accurate information about trading concepts, patterns, and strategies."
      });
      */

      // Simulate AI response with a timeout
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Mock responses based on keywords in the user's message
      let responseText = ""

      if (message.toLowerCase().includes("candlestick")) {
        responseText =
          "Candlestick patterns are visual representations of price movements. Common patterns include the Doji, Hammer, Engulfing patterns, and Morning/Evening stars. These patterns can help identify potential reversals or continuations in price trends."
      } else if (message.toLowerCase().includes("risk")) {
        responseText =
          "Risk management is crucial in trading. A common approach is the 1% rule, where you risk no more than 1% of your trading capital on a single trade. Always use stop losses and consider your risk-to-reward ratio before entering a trade."
      } else if (message.toLowerCase().includes("beginner") || message.toLowerCase().includes("start")) {
        responseText =
          "For beginners, I recommend focusing on education before trading with real money. Start with the basics of technical analysis, risk management, and trading psychology. Use TradeHive's quizzes and practice mode to build your skills without risking capital."
      } else {
        responseText =
          "That's an interesting question about trading. To provide more specific guidance, could you provide more details or context? I can help with pattern recognition, risk management, trading psychology, or specific trading strategies."
      }

      const aiResponse = {
        id: Date.now() + 1,
        role: "assistant",
        content: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }

      setMessages((prev) => [...prev, aiResponse])
    } catch (error) {
      console.error("Error getting AI response:", error)

      const errorMessage = {
        id: Date.now() + 1,
        role: "assistant",
        content: "I'm sorry, I encountered an error processing your request. Please try again later.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container py-10 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">AI Trading Assistant</h1>

      <Card className="h-[calc(100vh-12rem)]">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10 border-2 border-primary">
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="AI Assistant" />
              <AvatarFallback>AI</AvatarFallback>
            </Avatar>
            <div>
              <CardTitle>Trading Assistant</CardTitle>
              <CardDescription>Powered by advanced AI to help with your trading questions</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-grow overflow-hidden p-0">
          <ScrollArea className="h-[calc(100vh-16rem)] px-4">
            <div className="space-y-4 py-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${msg.role === "assistant" ? "" : "flex-row-reverse"}`}
                >
                  {msg.role === "assistant" ? (
                    <Avatar className="h-8 w-8 border-2 border-primary">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="AI Assistant" />
                      <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                  ) : (
                    <Avatar className="h-8 w-8">
                      <AvatarImage
                        src={user?.image || "/placeholder.svg?height=32&width=32"}
                        alt={user?.name || "User"}
                      />
                      <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={`rounded-lg p-3 max-w-[80%] ${
                      msg.role === "assistant" ? "bg-muted" : "bg-primary text-primary-foreground ml-auto"
                    }`}
                  >
                    <p className="text-sm">{msg.content}</p>
                    <p
                      className={`text-xs mt-1 ${
                        msg.role === "assistant" ? "text-muted-foreground" : "text-primary-foreground/80"
                      }`}
                    >
                      {msg.timestamp}
                    </p>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex items-start gap-3">
                  <Avatar className="h-8 w-8 border-2 border-primary">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="AI Assistant" />
                    <AvatarFallback>AI</AvatarFallback>
                  </Avatar>
                  <div className="rounded-lg p-3 bg-muted">
                    <div className="flex space-x-2 items-center">
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "0ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "150ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "300ms" }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
        </CardContent>
        <CardFooter className="p-4 border-t">
          <form onSubmit={handleSendMessage} className="flex w-full gap-2">
            <Input
              placeholder="Ask about trading concepts, patterns, or strategies..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              disabled={isLoading}
            />
            <Button type="submit" disabled={isLoading}>
              {isLoading ? <Brain className="h-4 w-4 animate-pulse" /> : <Send className="h-4 w-4" />}
              <span className="sr-only">Send</span>
            </Button>
          </form>
        </CardFooter>
      </Card>
    </div>
  )
}

