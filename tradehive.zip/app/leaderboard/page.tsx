"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Search, Trophy, Users } from "lucide-react"

// Mock leaderboard data
const leaderboardData = [
  {
    id: 1,
    name: "Alex Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 9850,
    quizzes: 42,
    accuracy: 92,
    rank: 1,
    badge: "Master Trader",
    isFriend: true,
  },
  {
    id: 2,
    name: "Sarah Chen",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 9720,
    quizzes: 38,
    accuracy: 94,
    rank: 2,
    badge: "Pattern Expert",
    isFriend: false,
  },
  {
    id: 3,
    name: "Michael Rodriguez",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 9580,
    quizzes: 45,
    accuracy: 89,
    rank: 3,
    badge: "Risk Manager",
    isFriend: true,
  },
  {
    id: 4,
    name: "Emma Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 9350,
    quizzes: 36,
    accuracy: 91,
    rank: 4,
    badge: "Speed Trader",
    isFriend: false,
  },
  {
    id: 5,
    name: "David Kim",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 9210,
    quizzes: 40,
    accuracy: 88,
    rank: 5,
    badge: "Master Trader",
    isFriend: true,
  },
  {
    id: 6,
    name: "Lisa Thompson",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 9050,
    quizzes: 35,
    accuracy: 90,
    rank: 6,
    badge: "Pattern Expert",
    isFriend: false,
  },
  {
    id: 7,
    name: "James Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 8920,
    quizzes: 39,
    accuracy: 87,
    rank: 7,
    badge: "Risk Manager",
    isFriend: false,
  },
  {
    id: 8,
    name: "Olivia Martinez",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 8780,
    quizzes: 33,
    accuracy: 92,
    rank: 8,
    badge: "Speed Trader",
    isFriend: true,
  },
  {
    id: 9,
    name: "Daniel Lee",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 8650,
    quizzes: 37,
    accuracy: 86,
    rank: 9,
    badge: "Master Trader",
    isFriend: false,
  },
  {
    id: 10,
    name: "Sophia Garcia",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 8520,
    quizzes: 34,
    accuracy: 89,
    rank: 10,
    badge: "Pattern Expert",
    isFriend: true,
  },
  // Current user
  {
    id: 42,
    name: "You",
    avatar: "/placeholder.svg?height=40&width=40",
    score: 5680,
    quizzes: 25,
    accuracy: 82,
    rank: 42,
    badge: "Rising Star",
    isCurrentUser: true,
  },
]

export default function LeaderboardPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [timeFrame, setTimeFrame] = useState("all-time")

  const filteredData = leaderboardData.filter((user) => user.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const friendsData = leaderboardData.filter((user) => user.isFriend || user.isCurrentUser)

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Leaderboard</h1>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div className="relative w-full md:w-auto">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search users..."
            className="pl-8 w-full md:w-[250px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={timeFrame === "weekly" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeFrame("weekly")}
          >
            Weekly
          </Button>
          <Button
            variant={timeFrame === "monthly" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeFrame("monthly")}
          >
            Monthly
          </Button>
          <Button
            variant={timeFrame === "all-time" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeFrame("all-time")}
          >
            All Time
          </Button>
        </div>
      </div>

      <Tabs defaultValue="global">
        <TabsList className="mb-6">
          <TabsTrigger value="global" className="flex items-center gap-2">
            <Trophy className="h-4 w-4" />
            Global
          </TabsTrigger>
          <TabsTrigger value="friends" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Friends
          </TabsTrigger>
        </TabsList>

        <TabsContent value="global">
          <Card>
            <CardHeader>
              <CardTitle>Global Rankings</CardTitle>
              <CardDescription>See how you compare to traders around the world</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-12 gap-2 p-4 font-medium border-b bg-muted/50">
                  <div className="col-span-1 text-center">Rank</div>
                  <div className="col-span-5 md:col-span-4">Trader</div>
                  <div className="col-span-2 text-right hidden md:block">Quizzes</div>
                  <div className="col-span-2 text-right hidden md:block">Accuracy</div>
                  <div className="col-span-4 md:col-span-3 text-right">Score</div>
                </div>

                <div className="divide-y">
                  {filteredData.map((user) => (
                    <div
                      key={user.id}
                      className={`grid grid-cols-12 gap-2 p-4 items-center ${
                        user.isCurrentUser ? "bg-primary/10" : ""
                      }`}
                    >
                      <div className="col-span-1 text-center font-medium">
                        {user.rank <= 3 ? (
                          <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary">
                            {user.rank}
                          </div>
                        ) : (
                          user.rank
                        )}
                      </div>
                      <div className="col-span-5 md:col-span-4 flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium flex items-center gap-2">
                            {user.name}
                            {user.isCurrentUser && (
                              <Badge variant="outline" className="ml-2">
                                You
                              </Badge>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground">{user.badge}</div>
                        </div>
                      </div>
                      <div className="col-span-2 text-right hidden md:block">{user.quizzes}</div>
                      <div className="col-span-2 text-right hidden md:block">{user.accuracy}%</div>
                      <div className="col-span-4 md:col-span-3 text-right font-medium">
                        {user.score.toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="friends">
          <Card>
            <CardHeader>
              <CardTitle>Friends Rankings</CardTitle>
              <CardDescription>See how you compare to your friends</CardDescription>
            </CardHeader>
            <CardContent>
              {friendsData.length > 0 ? (
                <div className="rounded-md border">
                  <div className="grid grid-cols-12 gap-2 p-4 font-medium border-b bg-muted/50">
                    <div className="col-span-1 text-center">Rank</div>
                    <div className="col-span-5 md:col-span-4">Trader</div>
                    <div className="col-span-2 text-right hidden md:block">Quizzes</div>
                    <div className="col-span-2 text-right hidden md:block">Accuracy</div>
                    <div className="col-span-4 md:col-span-3 text-right">Score</div>
                  </div>

                  <div className="divide-y">
                    {friendsData.map((user) => (
                      <div
                        key={user.id}
                        className={`grid grid-cols-12 gap-2 p-4 items-center ${
                          user.isCurrentUser ? "bg-primary/10" : ""
                        }`}
                      >
                        <div className="col-span-1 text-center font-medium">
                          {user.rank <= 3 ? (
                            <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary">
                              {user.rank}
                            </div>
                          ) : (
                            user.rank
                          )}
                        </div>
                        <div className="col-span-5 md:col-span-4 flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={user.avatar} alt={user.name} />
                            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium flex items-center gap-2">
                              {user.name}
                              {user.isCurrentUser && (
                                <Badge variant="outline" className="ml-2">
                                  You
                                </Badge>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">{user.badge}</div>
                          </div>
                        </div>
                        <div className="col-span-2 text-right hidden md:block">{user.quizzes}</div>
                        <div className="col-span-2 text-right hidden md:block">{user.accuracy}%</div>
                        <div className="col-span-4 md:col-span-3 text-right font-medium">
                          {user.score.toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">You haven't added any friends yet.</p>
                  <Button>Find Friends</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

