"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { BarChart2, Brain, Clock, Search, Shield } from "lucide-react"

export default function QuizzesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const quizzes = [
    {
      id: "basic-candlesticks",
      title: "Basic Candlestick Patterns",
      description: "Learn to identify the most common candlestick patterns",
      difficulty: "beginner",
      category: "patterns",
      questions: 10,
      timeEstimate: "15 min",
      icon: <BarChart2 className="h-5 w-5" />,
      completed: true,
    },
    {
      id: "advanced-candlesticks",
      title: "Advanced Candlestick Patterns",
      description: "Master complex candlestick formations and combinations",
      difficulty: "advanced",
      category: "patterns",
      questions: 15,
      timeEstimate: "25 min",
      icon: <BarChart2 className="h-5 w-5" />,
      completed: false,
    },
    {
      id: "risk-management",
      title: "Risk Management Fundamentals",
      description: "Learn how to properly manage risk in your trades",
      difficulty: "beginner",
      category: "risk",
      questions: 8,
      timeEstimate: "12 min",
      icon: <Shield className="h-5 w-5" />,
      completed: true,
    },
    {
      id: "risk-reward-ratios",
      title: "Risk-to-Reward Optimization",
      description: "Understand how to set optimal risk-to-reward ratios",
      difficulty: "intermediate",
      category: "risk",
      questions: 12,
      timeEstimate: "20 min",
      icon: <Shield className="h-5 w-5" />,
      completed: false,
    },
    {
      id: "time-challenge-1",
      title: "Speed Trading Challenge I",
      description: "Test your pattern recognition skills under time pressure",
      difficulty: "intermediate",
      category: "time",
      questions: 15,
      timeEstimate: "10 min",
      icon: <Clock className="h-5 w-5" />,
      completed: false,
    },
    {
      id: "market-psychology",
      title: "Trading Psychology",
      description: "Understand the psychological aspects of trading",
      difficulty: "intermediate",
      category: "psychology",
      questions: 10,
      timeEstimate: "15 min",
      icon: <Brain className="h-5 w-5" />,
      completed: false,
    },
  ]

  const filteredQuizzes = quizzes.filter(
    (quiz) =>
      quiz.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      quiz.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-500/10 text-green-500 hover:bg-green-500/20"
      case "intermediate":
        return "bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20"
      case "advanced":
        return "bg-red-500/10 text-red-500 hover:bg-red-500/20"
      default:
        return "bg-primary/10 text-primary hover:bg-primary/20"
    }
  }

  return (
    <div className="container py-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Trading Quizzes</h1>
          <p className="text-muted-foreground">Test your knowledge and improve your trading skills</p>
        </div>
        <div className="relative w-full md:w-auto">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search quizzes..."
            className="pl-8 w-full md:w-[250px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Quizzes</TabsTrigger>
          <TabsTrigger value="patterns">Candlestick Patterns</TabsTrigger>
          <TabsTrigger value="risk">Risk Management</TabsTrigger>
          <TabsTrigger value="time">Time Challenges</TabsTrigger>
        </TabsList>
        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuizzes.map((quiz) => (
              <QuizCard key={quiz.id} quiz={quiz} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="patterns">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuizzes
              .filter((quiz) => quiz.category === "patterns")
              .map((quiz) => (
                <QuizCard key={quiz.id} quiz={quiz} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="risk">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuizzes
              .filter((quiz) => quiz.category === "risk")
              .map((quiz) => (
                <QuizCard key={quiz.id} quiz={quiz} />
              ))}
          </div>
        </TabsContent>
        <TabsContent value="time">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuizzes
              .filter((quiz) => quiz.category === "time")
              .map((quiz) => (
                <QuizCard key={quiz.id} quiz={quiz} />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )

  function QuizCard({ quiz }: { quiz: (typeof quizzes)[0] }) {
    return (
      <Card className={quiz.completed ? "border-primary/50" : ""}>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="p-2 rounded-lg bg-primary/10">{quiz.icon}</div>
            <Badge className={`${getDifficultyColor(quiz.difficulty)}`}>
              {quiz.difficulty.charAt(0).toUpperCase() + quiz.difficulty.slice(1)}
            </Badge>
          </div>
          <CardTitle className="mt-4">{quiz.title}</CardTitle>
          <CardDescription>{quiz.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between text-sm text-muted-foreground">
            <div>{quiz.questions} questions</div>
            <div>{quiz.timeEstimate}</div>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" asChild>
            <Link href={`/quizzes/${quiz.id}`}>{quiz.completed ? "Retake Quiz" : "Start Quiz"}</Link>
          </Button>
        </CardFooter>
      </Card>
    )
  }
}

