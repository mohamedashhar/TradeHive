"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { ChevronLeft, ChevronRight, HelpCircle, Timer } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

// Mock quiz data - in a real app, this would come from an API
const quizData = {
  "basic-candlesticks": {
    title: "Basic Candlestick Patterns",
    description: "Learn to identify the most common candlestick patterns",
    questions: [
      {
        id: 1,
        question: "Which of the following patterns typically signals a bullish reversal?",
        options: ["Hanging Man", "Hammer", "Shooting Star", "Bearish Engulfing"],
        correctAnswer: 1,
        explanation:
          "A Hammer is a bullish reversal pattern that forms during a downtrend. It has a small body, little or no upper shadow, and a long lower shadow that's at least twice the size of the body.",
      },
      {
        id: 2,
        question: "What does a Doji candlestick pattern indicate?",
        options: ["Strong bullish momentum", "Strong bearish momentum", "Market indecision", "Guaranteed reversal"],
        correctAnswer: 2,
        explanation:
          "A Doji forms when the opening and closing prices are virtually equal. It indicates indecision in the market, with neither buyers nor sellers gaining control.",
      },
      {
        id: 3,
        question: "Which pattern consists of three consecutive candlesticks?",
        options: ["Engulfing Pattern", "Morning Star", "Doji", "Marubozu"],
        correctAnswer: 1,
        explanation:
          "A Morning Star is a three-candlestick pattern that signals a potential bullish reversal. It consists of a large bearish candle, followed by a small-bodied candle, and completed by a large bullish candle.",
      },
      {
        id: 4,
        question: "What is the main characteristic of a Marubozu candlestick?",
        options: [
          "It has long upper and lower shadows",
          "It has no shadows (or very small ones)",
          "It always indicates a reversal",
          "It has a small body",
        ],
        correctAnswer: 1,
        explanation:
          "A Marubozu candlestick has little to no upper or lower shadows, indicating that the open was near the low and the close was near the high (for a bullish Marubozu) or vice versa (for a bearish Marubozu).",
      },
      {
        id: 5,
        question: "Which of these patterns is considered a continuation pattern rather than a reversal pattern?",
        options: ["Hammer", "Shooting Star", "Rising Three Methods", "Evening Star"],
        correctAnswer: 2,
        explanation:
          "Rising Three Methods is a bullish continuation pattern that consists of a long bullish candle, followed by three small bearish candles contained within the range of the first candle, and completed by another bullish candle.",
      },
    ],
  },
  "risk-management": {
    title: "Risk Management Fundamentals",
    description: "Learn how to properly manage risk in your trades",
    questions: [
      {
        id: 1,
        question: "What is the recommended maximum percentage of your trading capital to risk on a single trade?",
        options: ["1-2%", "5-10%", "15-20%", "25-30%"],
        correctAnswer: 0,
        explanation:
          "Most professional traders recommend risking no more than 1-2% of your trading capital on a single trade. This helps ensure that a string of losses won't significantly deplete your account.",
      },
      {
        id: 2,
        question: "What is a stop-loss order?",
        options: [
          "An order to buy a security when it reaches a certain price",
          "An order to sell a security when it reaches a certain price to limit losses",
          "A strategy to average down on losing positions",
          "A method to increase position size when winning",
        ],
        correctAnswer: 1,
        explanation:
          "A stop-loss order is an order placed with a broker to sell a security when it reaches a certain price. It's designed to limit an investor's loss on a position and is a key risk management tool.",
      },
      {
        id: 3,
        question: "What is the risk-to-reward ratio?",
        options: [
          "The ratio of winning trades to losing trades",
          "The ratio of your account size to your position size",
          "The ratio of potential loss to potential profit on a trade",
          "The ratio of leverage to margin",
        ],
        correctAnswer: 2,
        explanation:
          "The risk-to-reward ratio compares the potential loss (risk) to the potential profit (reward) of a trade. A 1:3 risk-to-reward ratio means you're risking $1 to potentially make $3.",
      },
      {
        id: 4,
        question: "What is position sizing?",
        options: [
          "The process of determining how many shares or contracts to trade",
          "The size of your trading account",
          "The number of trades you make per day",
          "The length of time you hold a position",
        ],
        correctAnswer: 0,
        explanation:
          "Position sizing is the process of determining how many shares, contracts, or lots to trade based on your account size, risk tolerance, and the specific risk of the trade.",
      },
      {
        id: 5,
        question: "Which of the following is NOT a good risk management practice?",
        options: [
          "Using stop-loss orders",
          "Diversifying your trades",
          "Averaging down on losing positions",
          "Having a trading plan",
        ],
        correctAnswer: 2,
        explanation:
          "Averaging down (adding to losing positions) is generally considered a poor risk management practice as it increases your exposure to a trade that's already moving against you, potentially leading to larger losses.",
      },
      {
        id: 6,
        question: "What is the Kelly Criterion used for in trading?",
        options: [
          "To determine the optimal entry price",
          "To calculate the optimal position size based on win rate and risk-reward",
          "To predict market trends",
          "To measure volatility",
        ],
        correctAnswer: 1,
        explanation:
          "The Kelly Criterion is a formula used to determine the optimal size of a series of bets or trades. In trading, it helps determine how much of your capital to risk based on your win rate and risk-reward ratio.",
      },
      {
        id: 7,
        question: "What is drawdown in trading?",
        options: [
          "The process of withdrawing money from your trading account",
          "The decline in account value from a peak to a trough",
          "The commission paid to brokers",
          "The time it takes to execute a trade",
        ],
        correctAnswer: 1,
        explanation:
          "Drawdown refers to the peak-to-trough decline in a trading account's value. It measures the reduction in capital from the highest point to the lowest point during a specific period.",
      },
    ],
  },
  "advanced-candlesticks": {
    title: "Advanced Candlestick Patterns",
    description: "Master complex candlestick formations and combinations",
    questions: [
      {
        id: 1,
        question: "Which of these is a reliable bearish reversal pattern?",
        options: ["Three White Soldiers", "Bullish Harami", "Dark Cloud Cover", "Morning Star"],
        correctAnswer: 2,
        explanation:
          "Dark Cloud Cover is a bearish reversal pattern that forms after an uptrend. It consists of a bullish candle followed by a bearish candle that opens above the previous close and closes below the midpoint of the previous candle.",
      },
      {
        id: 2,
        question: "What is a Three Black Crows pattern?",
        options: [
          "A bullish continuation pattern",
          "A bearish reversal pattern with three consecutive bearish candles",
          "A neutral pattern indicating consolidation",
          "A pattern that only appears in ranging markets",
        ],
        correctAnswer: 1,
        explanation:
          "Three Black Crows is a bearish reversal pattern consisting of three consecutive bearish candles, each opening within the real body of the previous candle and closing near its low.",
      },
      {
        id: 3,
        question:
          "Which pattern is characterized by a small real body completely contained within the real body of the previous candle?",
        options: ["Engulfing", "Harami", "Doji", "Spinning Top"],
        correctAnswer: 1,
        explanation:
          "A Harami pattern is characterized by a small real body that is completely contained within the real body of the previous candle. It suggests a potential reversal in the current trend.",
      },
      {
        id: 4,
        question: "What does a Tweezer Top pattern indicate?",
        options: ["Bullish continuation", "Bearish reversal", "Bullish reversal", "Market indecision"],
        correctAnswer: 1,
        explanation:
          "A Tweezer Top pattern indicates a potential bearish reversal. It forms when two or more consecutive candles have identical highs, suggesting resistance at that level.",
      },
      {
        id: 5,
        question: "Which pattern consists of three bullish candles with each closing higher than the previous one?",
        options: ["Three White Soldiers", "Morning Star", "Bullish Engulfing", "Three Inside Up"],
        correctAnswer: 0,
        explanation:
          "Three White Soldiers is a bullish reversal pattern consisting of three consecutive bullish candles, each opening within the real body of the previous candle and closing near its high.",
      },
    ],
  },
}

export default function QuizPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const [currentQuiz, setCurrentQuiz] = useState<any>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [answers, setAnswers] = useState<(number | null)[]>([])
  const [showExplanation, setShowExplanation] = useState(false)
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutes in seconds
  const [quizResults, setQuizResults] = useState<{
    score: number
    correctAnswers: number
    totalQuestions: number
    timeTaken: number
    detailedResults: {
      questionIndex: number
      correct: boolean
      userAnswer: number | null
      correctAnswer: number
    }[]
  } | null>(null)

  useEffect(() => {
    // In a real app, fetch quiz data from API
    const quiz = quizData[params.id as keyof typeof quizData]
    if (quiz) {
      setCurrentQuiz(quiz)
      setAnswers(new Array(quiz.questions.length).fill(null))
    } else {
      router.push("/quizzes")
    }
  }, [params.id, router])

  useEffect(() => {
    if (!quizCompleted && currentQuiz) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer)
            handleQuizComplete()
            return 0
          }
          return prev - 1
        })
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [quizCompleted, currentQuiz])

  if (!currentQuiz) {
    return (
      <div className="container py-10 flex items-center justify-center">
        <p>Loading quiz...</p>
      </div>
    )
  }

  const currentQuestion = currentQuiz.questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / currentQuiz.questions.length) * 100

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOption(optionIndex)
    const newAnswers = [...answers]
    newAnswers[currentQuestionIndex] = optionIndex
    setAnswers(newAnswers)
  }

  const handleNextQuestion = () => {
    if (currentQuestionIndex < currentQuiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
      setSelectedOption(answers[currentQuestionIndex + 1])
      setShowExplanation(false)
    } else {
      handleQuizComplete()
    }
  }

  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
      setSelectedOption(answers[currentQuestionIndex - 1])
      setShowExplanation(false)
    }
  }

  const handleQuizComplete = () => {
    setQuizCompleted(true)

    // Calculate score
    let correctAnswers = 0
    const detailedResults = currentQuiz.questions.map((question: any, index: number) => {
      const isCorrect = answers[index] === question.correctAnswer
      if (isCorrect) correctAnswers++

      return {
        questionIndex: index,
        correct: isCorrect,
        userAnswer: answers[index],
        correctAnswer: question.correctAnswer,
      }
    })

    const score = Math.round((correctAnswers / currentQuiz.questions.length) * 100)
    const timeTaken = 300 - timeLeft // Time taken in seconds

    setQuizResults({
      score,
      correctAnswers,
      totalQuestions: currentQuiz.questions.length,
      timeTaken,
      detailedResults,
    })

    toast({
      title: "Quiz Completed!",
      description: `Your score: ${score}% (${correctAnswers}/${currentQuiz.questions.length})`,
    })
  }

  const handleShowExplanation = () => {
    setShowExplanation(true)
  }

  const handleRetakeQuiz = () => {
    setCurrentQuestionIndex(0)
    setSelectedOption(null)
    setAnswers(new Array(currentQuiz.questions.length).fill(null))
    setQuizCompleted(false)
    setTimeLeft(300)
    setQuizResults(null)
  }

  if (quizCompleted && quizResults) {
    return (
      <div className="container py-10 max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Quiz Results</CardTitle>
            <CardDescription>{currentQuiz.title}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-muted rounded-lg p-4 text-center">
                <div className="text-4xl font-bold mb-1">{quizResults.score}%</div>
                <div className="text-sm text-muted-foreground">Overall Score</div>
              </div>
              <div className="bg-muted rounded-lg p-4 text-center">
                <div className="text-4xl font-bold mb-1">
                  {quizResults.correctAnswers}/{quizResults.totalQuestions}
                </div>
                <div className="text-sm text-muted-foreground">Correct Answers</div>
              </div>
              <div className="bg-muted rounded-lg p-4 text-center">
                <div className="text-4xl font-bold mb-1">
                  {Math.floor(quizResults.timeTaken / 60)}:{(quizResults.timeTaken % 60).toString().padStart(2, "0")}
                </div>
                <div className="text-sm text-muted-foreground">Time Taken</div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Question Summary</h3>
              {currentQuiz.questions.map((question: any, index: number) => {
                const result = quizResults.detailedResults[index]
                return (
                  <div key={index} className="p-4 rounded-lg border">
                    <div className="flex items-start gap-2">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                          result.correct ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
                        }`}
                      >
                        {result.correct ? "✓" : "✗"}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{question.question}</p>
                        <div className="mt-2 space-y-1">
                          {question.options.map((option: string, optionIndex: number) => (
                            <div
                              key={optionIndex}
                              className={`p-2 rounded text-sm ${
                                optionIndex === question.correctAnswer
                                  ? "bg-green-500/10 text-green-500"
                                  : result.userAnswer === optionIndex && !result.correct
                                    ? "bg-red-500/10 text-red-500"
                                    : ""
                              }`}
                            >
                              {option}
                              {optionIndex === question.correctAnswer && " ✓"}
                              {result.userAnswer === optionIndex && !result.correct && " ✗"}
                            </div>
                          ))}
                        </div>
                        <div className="mt-3 text-sm text-muted-foreground">
                          <strong>Explanation:</strong> {question.explanation}
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row gap-4">
            <Button onClick={handleRetakeQuiz} className="w-full sm:w-auto">
              Retake Quiz
            </Button>
            <Button variant="outline" onClick={() => router.push("/quizzes")} className="w-full sm:w-auto">
              Back to Quizzes
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container py-10 max-w-3xl mx-auto">
      <div className="mb-8">
        <Button variant="outline" size="sm" onClick={() => router.push("/quizzes")}>
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Quizzes
        </Button>
      </div>

      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">{currentQuiz.title}</h1>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Timer className="h-4 w-4" />
          <span>{formatTime(timeLeft)}</span>
        </div>
      </div>

      <Progress value={progress} className="mb-8" />

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">
              Question {currentQuestionIndex + 1} of {currentQuiz.questions.length}
            </CardTitle>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon">
                  <HelpCircle className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Need Help?</DialogTitle>
                  <DialogDescription>You can use a hint, but it will affect your final score.</DialogDescription>
                </DialogHeader>
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm">
                    Hint: Look for the key characteristics of the candlestick pattern, such as the size of the body and
                    shadows, and its position relative to the trend.
                  </p>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <CardDescription className="text-lg font-medium">{currentQuestion.question}</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup value={selectedOption?.toString()} className="space-y-3">
            {currentQuestion.options.map((option: string, index: number) => (
              <div key={index} className="flex items-center space-x-2">
                <RadioGroupItem
                  value={index.toString()}
                  id={`option-${index}`}
                  onClick={() => handleOptionSelect(index)}
                />
                <Label htmlFor={`option-${index}`} className="flex-1 py-2 cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>

          {showExplanation && (
            <div className="mt-6 p-4 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2">Explanation:</h4>
              <p className="text-sm">{currentQuestion.explanation}</p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row justify-between gap-4">
          <div className="flex gap-2 w-full sm:w-auto">
            <Button
              variant="outline"
              onClick={handlePrevQuestion}
              disabled={currentQuestionIndex === 0}
              className="w-full sm:w-auto"
            >
              <ChevronLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button onClick={handleNextQuestion} disabled={selectedOption === null} className="w-full sm:w-auto">
              {currentQuestionIndex === currentQuiz.questions.length - 1 ? "Finish" : "Next"}
              {currentQuestionIndex !== currentQuiz.questions.length - 1 && <ChevronRight className="ml-2 h-4 w-4" />}
            </Button>
          </div>

          {!showExplanation && selectedOption !== null && (
            <Button variant="ghost" onClick={handleShowExplanation} className="w-full sm:w-auto">
              Show Explanation
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}

