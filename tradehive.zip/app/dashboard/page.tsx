"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, BookOpen, Brain, Trophy, Users } from "lucide-react"
import Link from "next/link"

// Mock quiz history data
const quizHistory = [
  {
    id: "risk-management",
    title: "Risk Management Fundamentals",
    date: "2 days ago",
    score: 85,
    questionsCorrect: 6,
    totalQuestions: 7,
    icon: <Brain className="h-5 w-5 text-primary" />,
  },
  {
    id: "basic-candlesticks",
    title: "Basic Candlestick Patterns",
    date: "5 days ago",
    score: 80,
    questionsCorrect: 4,
    totalQuestions: 5,
    icon: <BookOpen className="h-5 w-5 text-primary" />,
  },
  {
    id: "advanced-candlesticks",
    title: "Advanced Candlestick Patterns",
    date: "1 week ago",
    score: 60,
    questionsCorrect: 3,
    totalQuestions: 5,
    icon: <BarChart className="h-5 w-5 text-primary" />,
  },
]

export default function DashboardPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) {
      router.push("/signin")
    }
  }, [user, loading, router])

  if (loading || !user) {
    return (
      <div className="container flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <p>Loading...</p>
      </div>
    )
  }

  // Calculate overall stats
  const totalQuizzes = quizHistory.length
  const completedQuizzes = quizHistory.length
  const totalQuestions = quizHistory.reduce((acc, quiz) => acc + quiz.totalQuestions, 0)
  const correctAnswers = quizHistory.reduce((acc, quiz) => acc + quiz.questionsCorrect, 0)
  const averageScore = Math.round(quizHistory.reduce((acc, quiz) => acc + quiz.score, 0) / totalQuizzes)
  const quizCompletionRate = Math.round((completedQuizzes / 20) * 100) // Assuming 20 total quizzes available
  const accuracyRate = Math.round((correctAnswers / totalQuestions) * 100)

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Welcome back, {user.name}</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Quiz Completion</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{quizCompletionRate}%</div>
            <Progress value={quizCompletionRate} className="h-2 mt-2" />
            <p className="text-xs text-muted-foreground mt-2">{completedQuizzes}/20 quizzes completed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Accuracy Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{accuracyRate}%</div>
            <Progress value={accuracyRate} className="h-2 mt-2" />
            <p className="text-xs text-muted-foreground mt-2">
              {correctAnswers}/{totalQuestions} correct answers
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Leaderboard Rank</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">#42</div>
            <Progress value={58} className="h-2 mt-2" />
            <p className="text-xs text-muted-foreground mt-2">Top 10% of all users</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="recent-activity" className="mb-8">
        <TabsList className="grid grid-cols-3 md:grid-cols-5 mb-4">
          <TabsTrigger value="recent-activity">Recent Activity</TabsTrigger>
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="ai-insights" className="hidden md:block">
            AI Insights
          </TabsTrigger>
          <TabsTrigger value="community" className="hidden md:block">
            Community
          </TabsTrigger>
        </TabsList>
        <TabsContent value="recent-activity">
          <div className="grid grid-cols-1 gap-4">
            {quizHistory.map((quiz, index) => (
              <Card key={index}>
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="p-2 rounded-full bg-primary/10">{quiz.icon}</div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{quiz.title}</h3>
                        <p className="text-sm text-muted-foreground">Completed {quiz.date}</p>
                      </div>
                      <div className="text-right">
                        <div
                          className={`text-lg font-bold ${
                            quiz.score >= 80 ? "text-green-500" : quiz.score >= 60 ? "text-yellow-500" : "text-red-500"
                          }`}
                        >
                          {quiz.score}%
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {quiz.questionsCorrect}/{quiz.totalQuestions} correct
                        </p>
                      </div>
                    </div>
                    <div className="mt-2">
                      <Progress value={quiz.score} className="h-1.5" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            <Button variant="outline" className="mt-2" asChild>
              <Link href="/quizzes">View All Quiz History</Link>
            </Button>
          </div>
        </TabsContent>
        <TabsContent value="recommended">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                title: "Advanced Candlestick Patterns",
                description: "Learn to identify complex patterns for better trade entries",
                icon: <BarChart className="h-5 w-5 text-primary" />,
                href: "/quizzes/advanced-candlesticks",
                completionRate: 60,
              },
              {
                title: "Risk-to-Reward Mastery",
                description: "Optimize your trading with proper risk management",
                icon: <Brain className="h-5 w-5 text-primary" />,
                href: "/quizzes/risk-reward",
                completionRate: 0,
              },
            ].map((recommendation, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4">
                    <div className="p-2 w-fit rounded-full bg-primary/10">{recommendation.icon}</div>
                    <div>
                      <h3 className="font-medium text-lg">{recommendation.title}</h3>
                      <p className="text-sm text-muted-foreground mb-4">{recommendation.description}</p>
                      {recommendation.completionRate > 0 && (
                        <div className="mb-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress</span>
                            <span>{recommendation.completionRate}%</span>
                          </div>
                          <Progress value={recommendation.completionRate} className="h-1.5" />
                        </div>
                      )}
                      <Button asChild>
                        <Link href={recommendation.href}>
                          {recommendation.completionRate > 0 ? "Continue Learning" : "Start Learning"}
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="achievements">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                title: "Pattern Master",
                description: "Correctly identified 50 candlestick patterns",
                icon: <Trophy className="h-5 w-5 text-primary" />,
                unlocked: true,
                progress: 100,
              },
              {
                title: "Risk Manager",
                description: "Completed all risk management quizzes",
                icon: <Trophy className="h-5 w-5 text-primary" />,
                unlocked: true,
                progress: 100,
              },
              {
                title: "Speed Trader",
                description: "Completed 5 time challenges with 90%+ accuracy",
                icon: <Trophy className="h-5 w-5 text-primary" />,
                unlocked: false,
                progress: 60,
              },
            ].map((achievement, index) => (
              <Card key={index} className={!achievement.unlocked ? "opacity-80" : ""}>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center gap-4">
                    <div className={`p-3 rounded-full ${achievement.unlocked ? "bg-primary/10" : "bg-muted"}`}>
                      {achievement.icon}
                    </div>
                    <div>
                      <h3 className="font-medium">{achievement.title}</h3>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                      <div className="mt-3">
                        <Progress value={achievement.progress} className="h-1.5 mb-1" />
                        <p className="text-xs text-muted-foreground">
                          {achievement.unlocked ? "Completed" : `${achievement.progress}% complete`}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="ai-insights">
          <Card>
            <CardHeader>
              <CardTitle>AI Trading Insights</CardTitle>
              <CardDescription>Personalized recommendations based on your quiz performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <h3 className="font-medium mb-2">Pattern Recognition Improvement</h3>
                  <p className="text-sm text-muted-foreground">
                    Based on your quiz results, you're having difficulty with bullish reversal patterns. Focus on
                    practicing hammer and morning star patterns to improve your recognition skills.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <h3 className="font-medium mb-2">Risk Management Suggestion</h3>
                  <p className="text-sm text-muted-foreground">
                    Your risk-to-reward ratios tend to be too conservative. Consider taking trades with at least a 1:2
                    risk-to-reward ratio to improve your overall profitability.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <h3 className="font-medium mb-2">Score Analysis</h3>
                  <p className="text-sm text-muted-foreground">
                    Your average quiz score is {averageScore}%. You're doing well in risk management concepts (85%) but
                    need improvement in advanced candlestick patterns (60%). We recommend focusing on the Advanced
                    Candlestick Patterns quiz to improve your overall trading knowledge.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="community">
          <Card>
            <CardHeader>
              <CardTitle>Community Activity</CardTitle>
              <CardDescription>Recent discussions and events from the trading community</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    title: "Live Trading Session",
                    description: "Join the community for a live trading session this Friday at 2 PM EST",
                    icon: <Users className="h-5 w-5 text-primary" />,
                    time: "In 2 days",
                  },
                  {
                    title: "Hot Discussion: Market Analysis",
                    description: "Traders are discussing current market conditions in the public chat room",
                    icon: <Users className="h-5 w-5 text-primary" />,
                    time: "Active now",
                  },
                ].map((activity, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="p-2 rounded-full bg-primary/10 mt-1">{activity.icon}</div>
                    <div>
                      <h3 className="font-medium">{activity.title}</h3>
                      <p className="text-sm text-muted-foreground">{activity.description}</p>
                      <p className="text-xs text-primary mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-4" asChild>
                <Link href="/chat">Join Chat Rooms</Link>
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Continue Learning</CardTitle>
            <CardDescription>Pick up where you left off or start something new</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Button className="w-full" asChild>
                <Link href="/quizzes">Browse All Quizzes</Link>
              </Button>
              <Button className="w-full" variant="outline" asChild>
                <Link href="/practice">Practice Mode</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>AI Trading Assistant</CardTitle>
            <CardDescription>Get help with trading concepts and questions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="p-4 rounded-lg bg-muted mb-4">
              <p className="text-sm italic text-muted-foreground">
                "Ask me about candlestick patterns, risk management, or any trading concept you're struggling with."
              </p>
            </div>
            <Button className="w-full" asChild>
              <Link href="/ai-assistant">Chat with AI Assistant</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

