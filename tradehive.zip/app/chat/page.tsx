"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Lock, MessageSquare, Plus, Send, Users } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

// Mock chat room data
const publicRooms = [
  {
    id: "general",
    name: "General Trading",
    description: "Discuss general trading topics and strategies",
    members: 245,
    messages: [
      {
        id: 1,
        user: {
          name: "Alex Johnson",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        text: "Has anyone been watching the recent market volatility?",
        timestamp: "10:32 AM",
      },
      {
        id: 2,
        user: {
          name: "Sarah Chen",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        text: "Yes, it's been quite intense. I'm seeing a lot of bearish engulfing patterns on the daily charts.",
        timestamp: "10:35 AM",
      },
      {
        id: 3,
        user: {
          name: "Michael Rodriguez",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        text: "I've been focusing on risk management more than ever. Keeping position sizes small and using tight stop losses.",
        timestamp: "10:38 AM",
      },
      {
        id: 4,
        user: {
          name: "Emma Wilson",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        text: "Smart approach. What risk-to-reward ratios are you all targeting in this environment?",
        timestamp: "10:42 AM",
      },
      {
        id: 5,
        user: {
          name: "David Kim",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        text: "I'm not taking anything less than 1:3 right now. The volatility means bigger potential moves if you're patient.",
        timestamp: "10:45 AM",
      },
    ],
  },
  {
    id: "crypto",
    name: "Crypto Trading",
    description: "Discuss cryptocurrency trading strategies",
    members: 189,
    messages: [],
  },
  {
    id: "forex",
    name: "Forex Trading",
    description: "Discuss forex trading strategies and market analysis",
    members: 156,
    messages: [],
  },
]

const privateRooms = [
  {
    id: "advanced-traders",
    name: "Advanced Traders",
    description: "Private room for experienced traders",
    members: 12,
    messages: [],
  },
]

export default function ChatPage() {
  const { user } = useAuth()
  const [activeRoom, setActiveRoom] = useState("general")
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<any[]>([])
  const [privateRoomKey, setPrivateRoomKey] = useState("")
  const [newRoomName, setNewRoomName] = useState("")
  const [newRoomDescription, setNewRoomDescription] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Load messages for the active room
    const room = [...publicRooms, ...privateRooms].find((r) => r.id === activeRoom)
    if (room) {
      setMessages(room.messages || [])
    }

    // Scroll to bottom of messages
    scrollToBottom()
  }, [activeRoom])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (!message.trim() || !user) return

    const newMessage = {
      id: Date.now(),
      user: {
        name: user.name,
        avatar: user.image || "/placeholder.svg?height=40&width=40",
      },
      text: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, newMessage])
    setMessage("")

    // Scroll to bottom after sending message
    setTimeout(scrollToBottom, 100)
  }

  const handleJoinPrivateRoom = () => {
    // In a real app, this would validate the key against the server
    alert(`Joining private room with key: ${privateRoomKey}`)
    setPrivateRoomKey("")
  }

  const handleCreateRoom = () => {
    // In a real app, this would create a new room on the server
    alert(`Creating new room: ${newRoomName}`)
    setNewRoomName("")
    setNewRoomDescription("")
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Chat Rooms</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Trading Rooms</CardTitle>
              <CardDescription>Join public rooms or create your own</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Tabs defaultValue="public" className="w-full">
                <TabsList className="w-full rounded-none">
                  <TabsTrigger value="public" className="flex-1">
                    <Users className="mr-2 h-4 w-4" />
                    Public
                  </TabsTrigger>
                  <TabsTrigger value="private" className="flex-1">
                    <Lock className="mr-2 h-4 w-4" />
                    Private
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="public" className="m-0">
                  <ScrollArea className="h-[400px]">
                    <div className="p-4 space-y-2">
                      {publicRooms.map((room) => (
                        <Button
                          key={room.id}
                          variant={activeRoom === room.id ? "default" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => setActiveRoom(room.id)}
                        >
                          <div className="flex flex-col items-start">
                            <div className="font-medium">{room.name}</div>
                            <div className="text-xs text-muted-foreground">{room.members} members</div>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </ScrollArea>
                  <Separator />
                  <div className="p-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="w-full">
                          <Plus className="mr-2 h-4 w-4" />
                          Create Room
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Create a New Room</DialogTitle>
                          <DialogDescription>
                            Create a new public chat room for traders to join and discuss.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="room-name">Room Name</Label>
                            <Input
                              id="room-name"
                              placeholder="e.g., Technical Analysis"
                              value={newRoomName}
                              onChange={(e) => setNewRoomName(e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="room-description">Description</Label>
                            <Input
                              id="room-description"
                              placeholder="Briefly describe the room's purpose"
                              value={newRoomDescription}
                              onChange={(e) => setNewRoomDescription(e.target.value)}
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleCreateRoom}>Create Room</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </TabsContent>
                <TabsContent value="private" className="m-0">
                  <ScrollArea className="h-[400px]">
                    <div className="p-4 space-y-2">
                      {privateRooms.map((room) => (
                        <Button
                          key={room.id}
                          variant={activeRoom === room.id ? "default" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => setActiveRoom(room.id)}
                        >
                          <div className="flex flex-col items-start">
                            <div className="font-medium">{room.name}</div>
                            <div className="text-xs text-muted-foreground">{room.members} members</div>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </ScrollArea>
                  <Separator />
                  <div className="p-4 space-y-4">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Enter private room key"
                        value={privateRoomKey}
                        onChange={(e) => setPrivateRoomKey(e.target.value)}
                      />
                      <Button onClick={handleJoinPrivateRoom}>Join</Button>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="w-full">
                          <Plus className="mr-2 h-4 w-4" />
                          Create Private Room
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Create a Private Room</DialogTitle>
                          <DialogDescription>
                            Create a private room that others can join with a special key.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="private-room-name">Room Name</Label>
                            <Input
                              id="private-room-name"
                              placeholder="e.g., My Trading Group"
                              value={newRoomName}
                              onChange={(e) => setNewRoomName(e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="private-room-description">Description</Label>
                            <Input
                              id="private-room-description"
                              placeholder="Briefly describe the room's purpose"
                              value={newRoomDescription}
                              onChange={(e) => setNewRoomDescription(e.target.value)}
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleCreateRoom}>Create Private Room</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Card className="h-full flex flex-col">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>
                    {
                      (publicRooms.find((r) => r.id === activeRoom) || privateRooms.find((r) => r.id === activeRoom))
                        ?.name
                    }
                  </CardTitle>
                  <CardDescription>
                    {
                      (publicRooms.find((r) => r.id === activeRoom) || privateRooms.find((r) => r.id === activeRoom))
                        ?.description
                    }
                  </CardDescription>
                </div>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {
                    (publicRooms.find((r) => r.id === activeRoom) || privateRooms.find((r) => r.id === activeRoom))
                      ?.members
                  }{" "}
                  members
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex-grow overflow-hidden p-0">
              <ScrollArea className="h-[500px] p-4">
                {messages.length > 0 ? (
                  <div className="space-y-4">
                    {messages.map((msg) => (
                      <div key={msg.id} className="flex items-start gap-3">
                        <Avatar>
                          <AvatarImage src={msg.user.avatar} alt={msg.user.name} />
                          <AvatarFallback>{msg.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{msg.user.name}</span>
                            <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                          </div>
                          <p className="text-sm mt-1">{msg.text}</p>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No messages yet. Start the conversation!</p>
                    </div>
                  </div>
                )}
              </ScrollArea>
            </CardContent>
            <CardFooter className="p-4 border-t">
              {user ? (
                <form onSubmit={handleSendMessage} className="flex w-full gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  />
                  <Button type="submit">
                    <Send className="h-4 w-4" />
                    <span className="sr-only">Send</span>
                  </Button>
                </form>
              ) : (
                <div className="w-full text-center">
                  <p className="text-muted-foreground mb-2">Sign in to join the conversation</p>
                  <Button asChild>
                    <a href="/signin">Sign In</a>
                  </Button>
                </div>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

