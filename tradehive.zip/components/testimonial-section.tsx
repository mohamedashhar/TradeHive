import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"

export function TestimonialSection() {
  const testimonials = [
    {
      quote:
        "TradeHive helped me identify candlestick patterns with confidence. The interactive quizzes and AI insights have transformed my trading strategy.",
      name: "Alex Johnson",
      title: "Day Trader",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "The risk management section was a game-changer for me. I've reduced my losses and increased my win rate significantly.",
      name: "Sarah Chen",
      title: "Swing Trader",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "The community aspect of TradeHive is incredible. I've learned so much from other traders in the chat rooms.",
      name: "Michael Rodriguez",
      title: "Crypto Trader",
      avatar: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <section className="py-20 bg-background">
      <div className="container px-4 md:px-6 mx-auto">
        <div className="flex flex-col items-center text-center space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tighter">What Our Users Say</h2>
          <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
            Join thousands of traders who have improved their skills with TradeHive.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="relative">
                    <Avatar className="h-16 w-16 border-4 border-background">
                      <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                      <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                  </div>
                  <p className="italic text-muted-foreground">"{testimonial.quote}"</p>
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

