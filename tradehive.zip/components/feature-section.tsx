import { Award, BarChart, Clock, Lightbulb, LineChart, MessageSquare, Shield, Zap } from "lucide-react"

export function FeatureSection() {
  const features = [
    {
      icon: <BarChart className="h-10 w-10 text-primary" />,
      title: "Difficulty Levels",
      description: "Progress through beginner, intermediate, and advanced trading quizzes.",
    },
    {
      icon: <Award className="h-10 w-10 text-primary" />,
      title: "Progress Tracker",
      description: "Track your learning progress, quiz history, and accuracy over time.",
    },
    {
      icon: <LineChart className="h-10 w-10 text-primary" />,
      title: "Practice Mode",
      description: "Train with real-time generated candlestick charts for hands-on learning.",
    },
    {
      icon: <Shield className="h-10 w-10 text-primary" />,
      title: "Risk Management",
      description: "Learn how to calculate and apply proper risk management strategies.",
    },
    {
      icon: <Clock className="h-10 w-10 text-primary" />,
      title: "Time-Based Challenges",
      description: "Test your skills with competitive timed trading decision challenges.",
    },
    {
      icon: <Lightbulb className="h-10 w-10 text-primary" />,
      title: "Hints & Explanations",
      description: "Unlock hints or view detailed explanations for difficult patterns.",
    },
    {
      icon: <MessageSquare className="h-10 w-10 text-primary" />,
      title: "Chat Rooms",
      description: "Discuss strategies in public forums or create private chat rooms.",
    },
    {
      icon: <Zap className="h-10 w-10 text-primary" />,
      title: "AI Assistant",
      description: "Get help from our AI chatbot for trading concepts and questions.",
    },
  ]

  return (
    <section className="py-20 bg-muted/50">
      <div className="container px-4 md:px-6 mx-auto">
        <div className="flex flex-col items-center text-center space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tighter">
            Powerful Features to Enhance Your Trading Skills
          </h2>
          <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
            TradeHive offers a comprehensive suite of tools designed to help you become a better trader.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center p-6 bg-card rounded-lg border border-border hover:shadow-md transition-shadow"
            >
              <div className="p-3 rounded-full bg-primary/10 mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-center text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

