import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, BarChart2, Brain, Users } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative py-20 overflow-hidden bg-gradient-to-b from-background to-background/80">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1600')] bg-cover bg-center opacity-10"></div>
      <div className="container px-4 md:px-6 mx-auto relative z-10">
        <div className="flex flex-col items-center text-center space-y-4 mb-12">
          <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary mb-4">
            The Ultimate Trading Education Platform
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tighter">
            Master Trading with <span className="text-primary">TradeHive</span>
          </h1>
          <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
            Learn to identify candlestick patterns, understand risk-to-reward ratios, and connect with a community of
            traders.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mt-8">
            <Button size="lg" asChild>
              <Link href="/signup">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/demo">Try Demo</Link>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="flex flex-col items-center p-6 bg-card rounded-lg border border-border">
            <BarChart2 className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-bold mb-2">Interactive Quizzes</h3>
            <p className="text-center text-muted-foreground">
              Test your knowledge with quizzes on candlestick patterns and trading strategies.
            </p>
          </div>
          <div className="flex flex-col items-center p-6 bg-card rounded-lg border border-border">
            <Brain className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-bold mb-2">AI-Powered Insights</h3>
            <p className="text-center text-muted-foreground">
              Get personalized trading insights based on your quiz performance.
            </p>
          </div>
          <div className="flex flex-col items-center p-6 bg-card rounded-lg border border-border">
            <Users className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-bold mb-2">Trading Community</h3>
            <p className="text-center text-muted-foreground">
              Connect with other traders in public and private chat rooms.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

